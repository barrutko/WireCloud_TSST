﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WireCloud
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WindowWidth = 100;
            Console.BufferWidth = 100;
            LogWriter.startingMessage();
            
            string linksPath = Environment.CurrentDirectory + "\\Links.txt";
            LinkTable linkTable = new LinkTable(linksPath);
            
            string devicesPath = Environment.CurrentDirectory + "\\Devices.txt";
            DeviceContainer deviceContainer = new DeviceContainer(devicesPath, linkTable);

            Thread managerThread = new Thread(() => new CloudManager(linkTable, 6007));
            managerThread.Start();
            deviceContainer.initializeSockets();
            deviceContainer.run();
        }
    }
}
